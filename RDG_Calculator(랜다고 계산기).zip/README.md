# RDG_Calculator
It is RandomDice:Go Unofficial Calculator

execute RDG_Calculator.exe
RDG_Calculator.exe 파일을 실행해 주세요.
